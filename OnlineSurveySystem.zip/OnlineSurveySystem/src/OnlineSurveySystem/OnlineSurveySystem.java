package OnlineSurveySystem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class SurveyQuestion {
    private String question;
    private List<String> choices;

    public SurveyQuestion(String question, List<String> choices) {
        this.question = question;
        this.choices = choices;
    }

    public String getQuestion() {
        return question;
    }

    public List<String> getChoices() {
        return choices;
    }
}

class SurveyResponse {
    private String respondent;
    private Map<String, String> answers;
    private boolean isAnonymous;

    public SurveyResponse(String respondent, boolean isAnonymous) {
        this.respondent = respondent;
        this.answers = new HashMap<>();
        this.isAnonymous = isAnonymous;
    }

    public String getRespondent() {
        if (isAnonymous) {
            return "Anonymous";
        } else {
            return respondent;
        }
    }

    public void addAnswer(String question, String answer) {
        answers.put(question, answer);
    }

    public Map<String, String> getAnswers() {
        return answers;
    }
}

class Survey {
    private String title;
    private List<SurveyQuestion> questions;
    private List<SurveyResponse> responses;

    public Survey(String title, List<SurveyQuestion> questions) {
        this.title = title;
        this.questions = questions;
        this.responses = new ArrayList<>();
    }

    public void addResponse(SurveyResponse response) {
        responses.add(response);
    }

    public Map<String, Object> getSummaryStatistics() {
        Map<String, Object> statistics = new HashMap<>();

        for (SurveyQuestion question : questions) {
            Map<String, Integer> questionStats = new HashMap<>();
            int totalResponses = responses.size();

            for (String choice : question.getChoices()) {
                questionStats.put(choice, 0);
            }

            for (SurveyResponse response : responses) {
                String answer = response.getAnswers().get(question.getQuestion());
                questionStats.put(answer, questionStats.get(answer) + 1);
            }

            statistics.put(question.getQuestion(), totalResponses);
            statistics.put(question.getQuestion() + " Stats", questionStats);
        }

        return statistics;
    }
}

public class OnlineSurveySystem {
    public static void main(String[] args) {
        // Create survey questions
        List<SurveyQuestion> questions = new ArrayList<>();
        questions.add(new SurveyQuestion("How satisfied are you with the product?", List.of("Very satisfied", "Satisfied", "Neutral", "Dissatisfied", "Very dissatisfied")));
        questions.add(new SurveyQuestion("Would you recommend the product to others?", List.of("Definitely", "Probably", "Not sure", "Unlikely", "Definitely not")));
        questions.add(new SurveyQuestion("What is the best feature of the product?", List.of("Quality", "Design", "Functionality", "Price", "Customer support")));
        questions.add(new SurveyQuestion("What improvements would you like to see in the product?", List.of("More features", "Better performance", "Lower price", "Improved durability", "Easier to use")));

        // Create a survey
        Survey survey = new Survey("Product Review Survey", questions);

        // Collect responses
        Scanner scanner = new Scanner(System.in);
        String respondent;
        boolean isAnonymous;

        System.out.print("Do you want to allow anonymous responses? (yes/no): ");
        String allowAnonymous = scanner.nextLine();
        isAnonymous = allowAnonymous.equalsIgnoreCase("yes");

        do {
            System.out.print("Enter your name (or 'exit' to quit): ");
            respondent = scanner.nextLine();

            if (!respondent.equalsIgnoreCase("exit")) {
                SurveyResponse response = new SurveyResponse(respondent, isAnonymous);

                for (SurveyQuestion question : questions) {
                    System.out.println(question.getQuestion());

                    for (int i = 0; i < question.getChoices().size(); i++) {
                        System.out.println((i + 1) + ". " + question.getChoices().get(i));
                    }

                    int choice;
                    do {
                        System.out.print("Enter your choice: ");
                        choice = scanner.nextInt();
                        scanner.nextLine();
                    } while (choice < 1 || choice > question.getChoices().size());

                    response.addAnswer(question.getQuestion(), question.getChoices().get(choice - 1));
                }

                survey.addResponse(response);
                System.out.println("Thank you for your response!\n");
            }
        } while (!respondent.equalsIgnoreCase("exit"));

        // Print survey summary statistics
        Map<String, Object> statistics = survey.getSummaryStatistics();
        System.out.println("Survey Summary Statistics:\n");

        for (Map.Entry<String, Object> entry : statistics.entrySet()) {
            if (entry.getKey().endsWith(" Stats")) {
                System.out.println(entry.getKey());

                Map<String, Integer> questionStats = (Map<String, Integer>) entry.getValue();
                for (Map.Entry<String, Integer> questionEntry : questionStats.entrySet()) {
                    System.out.println(questionEntry.getKey() + ": " + questionEntry.getValue());
                }

                System.out.println();
            } else {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
    }
}
